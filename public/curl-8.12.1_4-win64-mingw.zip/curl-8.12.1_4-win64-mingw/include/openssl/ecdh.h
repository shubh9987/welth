/* $OpenBSD: ecdh.h,v 1.10 2023/07/28 09:25:12 tb Exp $ */
/*
 * Public domain.
 */

#include <openssl/ec.h>
